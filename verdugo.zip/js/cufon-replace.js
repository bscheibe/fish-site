Cufon.replace('.logo', { fontFamily: 'James Fajardo', textShadow:'1px 1px #113c88', hover:true });
Cufon.replace('h2', { fontFamily: 'Franklin Gothic Medium', hover:true });
Cufon.replace('h3', { fontFamily: 'Franklin Gothic Medium', hover:true });
Cufon.replace('h4', { fontFamily: 'Franklin Gothic Medium', hover:true });
Cufon.replace('.link-1', { fontFamily: 'Franklin Gothic Medium', hover:true });
Cufon.replace('.text-1', { fontFamily: 'Franklin Gothic Medium', hover:true });
